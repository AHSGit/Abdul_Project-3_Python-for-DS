import sqlite3
from flask import g

def connectDB():
    # Need to change URL to file location of database.db
    sql = sqlite3.connect('database.db')
    sql.row_factory = sqlite3.Row
    return sql

def getDB():
    if not hasattr(g, 'database_db'):
        g.database_db = connectDB()
    return g.database_db