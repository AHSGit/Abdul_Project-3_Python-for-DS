from flask import Flask, redirect, render_template, jsonify, request, url_for
from dbconnector import getDB
from flask_bcrypt import Bcrypt
import pickle
import numpy as np

app = Flask(__name__)
model = pickle.load(open('model.pkl', 'rb'))

app.config['SECRET_KEY'] = 'secretkey'
bcrypt = Bcrypt(app)

# API for home page
@app.route('/', methods=['GET'])
def home():
    return render_template("home.html")

# API for register page
@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashedPW = bcrypt.generate_password_hash(password)
        db = getDB()
        db.execute("insert into users (username, password) values (?,?)", [
                   username, hashedPW])
        db.commit()
        db.close()
        return redirect(url_for('login'))
    return render_template("register.html")

# API for login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        entered_password = request.form['password']
        db = getDB()
        userCursor = db.execute(
            "select * from users where username = ?", [username])
        currentUser = userCursor.fetchone()

        if currentUser:
            if bcrypt.check_password_hash(currentUser['password'], entered_password):
                return redirect(url_for('enter_details'))
            else:
                return redirect(url_for('login'))

    return render_template("login.html")

# API enter-details that renders the predict.html page
@app.route('/enter_details', methods=['GET'])
def enter_details():
    return render_template("predict.html")

# API that renders the prediction results on the HTML template
@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        gender = request.form['gender']
        married = request.form['married']
        dependents = request.form['dependents']
        education = request.form['education']
        self_employed = request.form['self_employed']
        applicantincome = request.form['applicantincome']
        coapplicantincome = request.form['coapplicantincome']
        loanamount = request.form['loanamount']
        loan_amount_term = request.form['loan_amount_term']
        credit_history = request.form['credit_history']
        property_area = request.form['property_area']

        params = [gender, married, dependents, education, self_employed, applicantincome,
                  coapplicantincome, loanamount, loan_amount_term, credit_history, property_area]
        num_params = np.array(params, dtype=int)
       
        prediction = model.predict([num_params])

        if (prediction == 'n'):
            return render_template('predict.html', prediction_text="Sorry! You are not eligible for the loan.")
        else:
            return render_template('predict.html', prediction_text="Congrats! You are eligible for the loan.")

    else:
        return render_template('predict.html')

# API to logout the user that takes them to home page
@app.route('/logout', methods=['GET'])
def logout():
    return render_template("home.html")


if __name__ == "__main__":
    app.run(debug=True)


    

# from flask_sqlalchemy import SQLAlchemy
# from flask_login import UserMixin
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
# db = SQLAlchemy(app)
# class User(db.Model, UserMixin):
#     id = db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(100), nullable=False, unique=True)
#     password = db.Column(db.String(100), nullable=False)
# with app.app_context():
#      db.create_all()